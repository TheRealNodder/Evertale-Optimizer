Evertale Local Image Generator

1. Run: python download_images.py
2. Images saved into images/characters_large/
3. Upload that folder to your GitHub repo.
