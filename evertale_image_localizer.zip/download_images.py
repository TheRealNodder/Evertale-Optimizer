import json, os, requests

with open("image_map.json","r",encoding="utf-8") as f:
    data=json.load(f)

os.makedirs("images/characters_large",exist_ok=True)

for name,url in data.items():
    fn=f"images/characters_large/{name}.png"
    try:
        r=requests.get(url,timeout=10)
        if r.status_code==200:
            with open(fn,"wb") as out:
                out.write(r.content)
            print("OK:",name)
        else:
            print("MISS:",name,r.status_code)
    except Exception as e:
        print("ERR:",name,e)
