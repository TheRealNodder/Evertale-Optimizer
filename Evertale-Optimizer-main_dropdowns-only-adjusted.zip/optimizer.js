/* optimizer.js — WHOLE FILE
   Adds slot-locks for Story + Platoons and passes to engine.
*/

const DATA_CHARACTERS = "./data/characters.json";
// Current + legacy keys (older builds used `evertale_owned`).
const OWNED_KEY = "evertale_owned_units_v1";
const OWNED_KEY_LEGACY = "evertale_owned";

// NOTE:
// Some earlier builds referenced a helper named `renderImageStateControls()`
// during init but did not include the definition, which crashes the optimizer
// page (and prevents owned units from loading). Keep a safe implementation
// here so the page always boots.
function renderImageStateControls() {
  // Intentionally a no-op initializer for older builds.
  // Per-card state buttons (when present) are handled via event delegation.
}
const LAYOUT_KEY = "evertale_team_layout_v1";

const LS_TEAMTYPE_KEY = "evertale_optimizer_teamType_v1";
const LS_PRESET_KEY = "evertale_optimizer_preset_v1";
const LS_LOCKS_KEY = "evertale_optimizer_slotLocks_v1";
const LS_PRIMARY_ARCHETYPE_KEY = "evertale_optimizer_primaryArchetype_v1";
const LS_SECONDARY_ARCHETYPE_KEY = "evertale_optimizer_secondaryArchetype_v1";

const ARCHETYPE_OPTIONS = new Set(["","burn","poison","sleep","stun","heal","turn","cleanse","defense","stealth","spirit","charge"]);

const STORY_MAIN = 5;
const STORY_BACK = 3;
const PLATOON_COUNT = 20;
const PLATOON_SIZE = 5;

const state = {
  all: [],
  ownedIds: new Set(),
  ownedUnits: [],
  layout: null,
  locks: null, // { storyMain:bool[5], storyBack:bool[3], platoons:bool[20][5] }
  mode: "story",
  exampleMode: false, // when true, slots can show units not owned (greyed out)
};

function el(id) { return document.getElementById(id); }
function safeJsonParse(raw, fallback) { try { return JSON.parse(raw); } catch { return fallback; } }
function normId(v) { return (v == null || v === "") ? "" : String(v); }

function getTeamTypePref() {
  const v = localStorage.getItem(LS_TEAMTYPE_KEY);
  return (v === "mono" || v === "rainbow" || v === "auto") ? v : "auto";
}
function getPresetPref() {
  const allowed = new Set(["auto","burn","poison","sleep","stun","heal","turn","atkBuff","hpBuff","cleanse"]);
  const v = localStorage.getItem(LS_PRESET_KEY) || "auto";
  return allowed.has(v) ? v : "auto";
}
function setTeamTypePref(v) { localStorage.setItem(LS_TEAMTYPE_KEY, v); }
function setPresetPref(v) { localStorage.setItem(LS_PRESET_KEY, v); }
function getPrimaryArchetypePref() {
  const v = localStorage.getItem(LS_PRIMARY_ARCHETYPE_KEY) || "";
  return ARCHETYPE_OPTIONS.has(v) ? v : "";
}
function getSecondaryArchetypePref() {
  const v = localStorage.getItem(LS_SECONDARY_ARCHETYPE_KEY) || "";
  return ARCHETYPE_OPTIONS.has(v) ? v : "";
}
function setPrimaryArchetypePref(v) { localStorage.setItem(LS_PRIMARY_ARCHETYPE_KEY, ARCHETYPE_OPTIONS.has(v) ? v : ""); }
function setSecondaryArchetypePref(v) { localStorage.setItem(LS_SECONDARY_ARCHETYPE_KEY, ARCHETYPE_OPTIONS.has(v) ? v : ""); }

function defaultLocks() {
  return {
    storyMain: Array(STORY_MAIN).fill(false),
    storyBack: Array(STORY_BACK).fill(false),
    platoons: Array.from({ length: PLATOON_COUNT }, () => Array(PLATOON_SIZE).fill(false)),
  };
}

function loadLocks() {
  const obj = safeJsonParse(localStorage.getItem(LS_LOCKS_KEY) || "null", null);
  const base = defaultLocks();
  if (!obj) return base;

  if (Array.isArray(obj.storyMain)) base.storyMain = obj.storyMain.slice(0,STORY_MAIN).map(Boolean);
  if (Array.isArray(obj.storyBack)) base.storyBack = obj.storyBack.slice(0,STORY_BACK).map(Boolean);
  if (Array.isArray(obj.platoons)) {
    base.platoons = obj.platoons.slice(0,PLATOON_COUNT).map(row => {
      const r = Array.isArray(row) ? row.slice(0,PLATOON_SIZE).map(Boolean) : [];
      return r.concat(Array(PLATOON_SIZE).fill(false)).slice(0,PLATOON_SIZE);
    });
    while (base.platoons.length < PLATOON_COUNT) base.platoons.push(Array(PLATOON_SIZE).fill(false));
  }
  return base;
}

function saveLocks() {
  localStorage.setItem(LS_LOCKS_KEY, JSON.stringify(state.locks));
}

function syncArchetypeDropdowns() {
  const primarySel = el("primaryArchetypeSelect");
  const secondarySel = el("secondaryArchetypeSelect");
  const primary = primarySel?.value || "";
  const secondary = secondarySel?.value || "";

  if (secondarySel) {
    Array.from(secondarySel.options).forEach(opt => {
      if (!opt.value) { opt.disabled = false; return; }
      opt.disabled = opt.value === primary;
    });
    if (secondary && secondary === primary) secondarySel.value = "";
  }
}

function initSharedOptimizerFiltersUI() {
  const teamSel = el("teamTypeSelect");
  const presetSel = el("presetSelect");
  const primarySel = el("primaryArchetypeSelect");
  const secondarySel = el("secondaryArchetypeSelect");
  if (teamSel) teamSel.value = getTeamTypePref();
  if (presetSel) presetSel.value = getPresetPref();
  if (primarySel) primarySel.value = getPrimaryArchetypePref();
  if (secondarySel) secondarySel.value = getSecondaryArchetypePref();
  syncArchetypeDropdowns();
  teamSel?.addEventListener("change", (e) => setTeamTypePref(e.target.value || "auto"));
  presetSel?.addEventListener("change", (e) => setPresetPref(e.target.value || "auto"));
  primarySel?.addEventListener("change", (e) => {
    setPrimaryArchetypePref(e.target.value || "");
    syncArchetypeDropdowns();
  });
  secondarySel?.addEventListener("change", (e) => {
    setSecondaryArchetypePref(e.target.value || "");
    syncArchetypeDropdowns();
  });
}

function getOwnedIds() {
  const rawCurrent = localStorage.getItem(OWNED_KEY);
  const rawLegacy = localStorage.getItem(OWNED_KEY_LEGACY);

  let ids = safeJsonParse(rawCurrent || "null", null);
  if (!Array.isArray(ids)) {
    ids = safeJsonParse(rawLegacy || "[]", []);
  }
  ids = Array.isArray(ids) ? ids : [];

  // If we're reading from legacy, also write-through to the current key.
  if (!rawCurrent && rawLegacy && ids.length) {
    try { localStorage.setItem(OWNED_KEY, JSON.stringify(ids)); } catch (_) {}
  }

  return new Set(ids.map(normId).filter(Boolean));
}

function loadLayout() {
  const empty = {
    storyMain: Array(STORY_MAIN).fill(""),
    storyBack: Array(STORY_BACK).fill(""),
    platoons: Array.from({ length: PLATOON_COUNT }, () => Array(PLATOON_SIZE).fill("")),
  };

  const obj = safeJsonParse(localStorage.getItem(LAYOUT_KEY) || "null", null);
  if (!obj) return empty;

  obj.storyMain = Array.isArray(obj.storyMain) ? obj.storyMain.map(normId) : empty.storyMain;
  obj.storyBack = Array.isArray(obj.storyBack) ? obj.storyBack.map(normId) : empty.storyBack;
  obj.platoons  = Array.isArray(obj.platoons) ? obj.platoons : empty.platoons;

  obj.storyMain = obj.storyMain.slice(0, STORY_MAIN).concat(Array(STORY_MAIN).fill("")).slice(0, STORY_MAIN);
  obj.storyBack = obj.storyBack.slice(0, STORY_BACK).concat(Array(STORY_BACK).fill("")).slice(0, STORY_BACK);

  obj.platoons = obj.platoons.slice(0, PLATOON_COUNT);
  while (obj.platoons.length < PLATOON_COUNT) obj.platoons.push(Array(PLATOON_SIZE).fill(""));

  obj.platoons = obj.platoons.map(row => {
    const r = Array.isArray(row) ? row.map(normId) : [];
    return r.slice(0, PLATOON_SIZE).concat(Array(PLATOON_SIZE).fill("")).slice(0, PLATOON_SIZE);
  });

  return obj;
}

function saveLayout() {
  localStorage.setItem(LAYOUT_KEY, JSON.stringify(state.layout));
}

async function loadCharacters() {
  const raw = window.EvertaleData && window.EvertaleData.loadCharactersMerged
    ? await window.EvertaleData.loadCharactersMerged()
    : [];

  const seen = new Set();
  const deduped = [];
  for (const u of raw) {
    const id = normId(u?.id);
    if (!id) continue;
    if (seen.has(id)) continue;
    seen.add(id);
    deduped.push(u);
  }

  return deduped;
}

function optionList(units) {
  const opts = [`<option value="">(empty)</option>`];
  for (const u of units) {
    opts.push(`<option value="${normId(u.id)}">${u.name} (${u.element} ${u.rarity})</option>`);
  }
  return opts.join("");
}

function slotCardHTML(slotKey, idx, currentId, poolUnits, locked, ownedIdSet){
  const currentNorm = normId(currentId || "");
  const isPlatoon = String(slotKey).startsWith("platoon_");

  // Build options from the current pool (owned for normal mode, all for example mode)
  const opts = [];
  opts.push({ value: "", label: "(empty)" });
  for (const u of (poolUnits || [])) {
    const id = normId(u?.id);
    if (!id) continue;
    const el = u?.element || "";
    const rar = u?.rarity || "";
    opts.push({ value: id, label: `${u?.name || "?"} (${el} ${rar})` });
  }

  const selectedUnit = (poolUnits || []).find(u => normId(u?.id) === currentNorm) || null;
  const name = selectedUnit?.name || "?";
  const title = selectedUnit?.title || (isPlatoon ? "Select a unit" : "");
  const element = selectedUnit?.element || "";
  const rarity = selectedUnit?.rarity || "";
  const kind = isPlatoon ? "platoon" : (String(slotKey).includes("Main") ? "main" : "back");

  const isOwned = !currentNorm ? true : !!(ownedIdSet && ownedIdSet.has(currentNorm));
  const ownedClass = (!isOwned && selectedUnit) ? "missingOwned" : "";

  const elClass = element ? `el-${String(element).toLowerCase()}` : "el-none";
  const rarClass = rarity ? `rar-${String(rarity).toLowerCase()}` : "rar-none";

  const img = selectedUnit?.image
    ? `<img class="${isPlatoon ? "unitPortrait" : ""}" src="${selectedUnit.image}" alt="${name}" loading="lazy" decoding="async" />`
    : (isPlatoon ? `<div class="unitPortraitPlaceholder">?</div>` : ``);

  const selectHtml = `
    <select class="slotSelect" data-slot="${slotKey}" data-idx="${idx}">
      ${opts.map(o => `<option value="${o.value}" ${o.value===currentNorm ? "selected" : ""}>${o.label}</option>`).join("")}
    </select>
  `;

  const lockHtml = isPlatoon
    ? `<label class="lockRow"><input type="checkbox" class="slotLock" data-slot="${slotKey}" data-idx="${idx}" ${locked ? "checked" : ""}/> <span>Lock</span></label>`
    : `<label class="lockRow"><input type="checkbox" class="slotLock" data-slot="${slotKey}" data-idx="${idx}" ${locked ? "checked" : ""}/> Lock</label>`;

  // Platoon: compact card to match your revamped UI
  if (isPlatoon) {
    return `
      <div class="slotCard platoonSlotCard ${kind} ${elClass} ${rarClass} ${ownedClass}" data-element="${element}" data-rarity="${rarity}">
        <div class="slotTop">
          <div class="slotImg">${img}</div>
        </div>

        <div class="slotMid">
          ${selectHtml}
          <div class="slotTitle">${title}</div>
          <div class="slotBadges">
            <span class="tag kind">Platoon</span>
            ${element ? `<span class="tag element ${String(element).toLowerCase()}">${element}</span>` : ``}
            ${rarity ? `<span class="tag rarity ${String(rarity).toLowerCase()}">${rarity}</span>` : ``}
          </div>
        </div>

        <div class="slotBottom">
          ${lockHtml}
        </div>
      </div>`;
  }

  // Story: original-ish card (keeps your existing layout expectations)
  const stats = selectedUnit ? `<div class="slotStats">ATK ${selectedUnit.atk} · HP ${selectedUnit.hp} · SPD ${selectedUnit.spd} · COST ${selectedUnit.cost}</div>` : "";
  const badges = selectedUnit ? `<div class="slotBadges"><span class="badge">${rarity}</span><span class="badge">${element}</span></div>` : "";

  return `
    <div class="slotCard storySlotCard ${kind} ${elClass} ${rarClass} ${ownedClass}" data-element="${element}" data-rarity="${rarity}">
      <div class="slotTop">
        <div class="slotImg">${selectedUnit?.image ? `<img src="${selectedUnit.image}" alt="${name}" loading="lazy" decoding="async">` : ""}</div>
        <div class="slotName">${name}</div>
      </div>
      <div class="slotMid">${title}${badges}${stats}</div>
      <div class="slotBottom">${selectHtml}${lockHtml}</div>
    </div>`;
}



function getLockFor(slotKey, idx) {
  if (slotKey === "storyMain") return !!state.locks.storyMain[idx];
  if (slotKey === "storyBack") return !!state.locks.storyBack[idx];
  if (slotKey.startsWith("platoon_")) {
    const p = parseInt(slotKey.split("_")[1], 10);
    return !!state.locks.platoons[p][idx];
  }
  return false;
}

function setLockFor(slotKey, idx, val) {
  if (slotKey === "storyMain") state.locks.storyMain[idx] = !!val;
  else if (slotKey === "storyBack") state.locks.storyBack[idx] = !!val;
  else if (slotKey.startsWith("platoon_")) {
    const p = parseInt(slotKey.split("_")[1], 10);
    state.locks.platoons[p][idx] = !!val;
  }
  saveLocks();
}

function wireSelects() {
  document.querySelectorAll("select.slotSelect").forEach(sel => {
    const slot = sel.getAttribute("data-slot");
    const idx = parseInt(sel.getAttribute("data-idx"), 10);

    let current = "";
    if (slot === "storyMain") current = state.layout.storyMain[idx] || "";
    else if (slot === "storyBack") current = state.layout.storyBack[idx] || "";
    else if (slot.startsWith("platoon_")) {
      const p = parseInt(slot.split("_")[1], 10);
      current = state.layout.platoons[p][idx] || "";
    }

    sel.value = normId(current);

    sel.addEventListener("change", () => {
      const v = normId(sel.value);
      if (slot === "storyMain") state.layout.storyMain[idx] = v;
      else if (slot === "storyBack") state.layout.storyBack[idx] = v;
      else if (slot.startsWith("platoon_")) {
        const p = parseInt(slot.split("_")[1], 10);
        state.layout.platoons[p][idx] = v;
      }
      saveLayout();
      renderAll();
    });
  });

  document.querySelectorAll("input.slotLock").forEach(cb => {
    const slot = cb.getAttribute("data-slot");
    const idx = parseInt(cb.getAttribute("data-idx"), 10);
    cb.addEventListener("change", () => {
      setLockFor(slot, idx, cb.checked);
      renderAll();
    });
  });
}

function renderStory() {
  const mainEl = el("storyMain");
  const backEl = el("storyBack");
  if (!mainEl || !backEl) return;

  const pool = state.exampleMode ? state.all : state.ownedUnits;
  mainEl.innerHTML = state.layout.storyMain.map((id,i) =>
    slotCardHTML("storyMain", i, id, pool, getLockFor("storyMain", i), state.ownedIds)
  ).join("");

  backEl.innerHTML = state.layout.storyBack.map((id,i) =>
    slotCardHTML("storyBack", i, id, pool, getLockFor("storyBack", i), state.ownedIds)
  ).join("");
}

function renderPlatoons() {
  const grid = el("platoonsGrid");
  if (!grid) return;

  const pool = state.exampleMode ? state.all : state.ownedUnits;
  grid.innerHTML = state.layout.platoons.map((row,p) => {
    const slots = row.map((id,i) =>
      slotCardHTML(`platoon_${p}`, i, id, pool, getLockFor(`platoon_${p}`, i), state.ownedIds)
    ).join("");

    return `
      <div class="panel platoonPanel">
        <div class="panelTitle">Platoon ${p+1}</div>
        <div class="slotGrid platoonSlots">${slots}</div>
      </div>
    `;
  }).join("");
}

function renderStorage() {
  const grid = el("storageGrid");
  if (!grid) return;

  const used = new Set([
    ...state.layout.storyMain.filter(Boolean),
    ...state.layout.storyBack.filter(Boolean),
    ...state.layout.platoons.flat().filter(Boolean),
  ].map(normId));

  const remaining = state.ownedUnits.filter(u => !used.has(normId(u.id)));

  grid.innerHTML = remaining.map(u => {
    const img = u.image ? `<img src="${u.image}" alt="">` : `<div class="ph">?</div>`;
    return `
      <div class="slotCard">
        <div class="slotTop">
          <div class="slotImg">${img}</div>
          <div>
            <div class="slotName">${u.name}</div>
            <div class="slotSub">${u.title || ""}</div>
          </div>
        </div>
        <div class="slotMetaRow">
          <span class="slotChip">${u.rarity || ""}</span>
          <span class="slotChip">${u.element || ""}</span>
        </div>
      </div>
    `;
  }).join("");
}

function renderAll() {
  el("ownedCount") && (el("ownedCount").textContent = `${state.ownedUnits.length} selected`);
  el("ownedPoolText") && (el("ownedPoolText").textContent = `${state.ownedUnits.length} owned units available`);

  const storySection = el("storySection");
  const platoonsSection = el("platoonsSection");
  if (storySection && platoonsSection) {
    if (state.mode === "story") {
      storySection.classList.remove("hidden");
      platoonsSection.classList.add("hidden");
    } else {
      storySection.classList.add("hidden");
      platoonsSection.classList.remove("hidden");
    }
  }

  renderStory();
  renderPlatoons();
  renderStorage();
  wireSelects();
}

function buildExampleOptions() {
  // Example teams ignore owned constraints for selection, but we keep ownedIds for grey-out.
  const teamType = (el("teamTypeSelect")?.value || getTeamTypePref());
  const preset = (el("presetSelect")?.value || getPresetPref());
  const style = (el("exampleStyleSelect")?.value || "best");

  const options = buildEngineOptions();
  if (["burn","poison","sleep","stun","heal","turn","cleanse"].includes(style) && (!options.archetypes || !options.archetypes.length)) {
    options.archetypes = [style];
  }

  // Force preset behavior for examples
  // - "best": let engine auto-pick (and we allow presetSelect to bias if user chose a specific preset)
  // - other styles: choose a practical preset mapping
  if (style === "best") {
    options.presetTag = (preset === "auto") ? "" : preset;
    options.presetMode = (preset === "auto") ? "auto" : "hard";
  } else if (["burn","poison","sleep","stun","heal","turn","atkBuff","hpBuff","cleanse"].includes(style)) {
    options.presetTag = style;
    options.presetMode = "hard";
  } else if (style === "aggro") {
    // Practical aggressive examples: bias toward ATK buff / pressure teams.
    options.presetTag = "atkBuff";
    options.presetMode = "hard";
  } else if (style === "timestop") {
    // Tempo/control examples.
    options.presetTag = "turn";
    options.presetMode = "hard";
  } else if (style === "sustain") {
    // Healing / cleanse / revive examples.
    options.presetTag = "heal";
    options.presetMode = "hard";
  }

  // Keep team type selection as-is
  if (teamType === "mono") options.doctrineOverrides.monoVsRainbow = { selectionMode: "force_mono" };
  else if (teamType === "rainbow") options.doctrineOverrides.monoVsRainbow = { selectionMode: "force_rainbow" };
  else options.doctrineOverrides.monoVsRainbow = { selectionMode: "auto" };

  return options;
}

function buildExampleTeam() {
  if (!window.OptimizerEngine || typeof window.OptimizerEngine.run !== "function") return;
  if (!state.all || !state.all.length) return;

  state.exampleMode = true;
  // Example teams should only suggest SSRs and can include units not owned.
  const ssrPool = state.all.filter(u => String(u?.rarity || "").toUpperCase() === "SSR");
  const style = (el("exampleStyleSelect")?.value || "best");

  let result = null;

  // For "best", actually try all practical preset families and keep the
  // highest-scoring example instead of relying on the generic auto path.
  if (style === "best") {
    const candidatePresets = ["burn","poison","sleep","stun","heal","turn","cleanse","atkBuff","hpBuff"];
    let best = null;
    let bestScore = -Infinity;

    for (const presetKey of candidatePresets) {
      const options = buildEngineOptions();
      options.presetTag = presetKey;
      options.presetMode = "hard";
      const candidate = window.OptimizerEngine.run(ssrPool, options);
      const score = Number(candidate?.totalScore || 0);
      if (score > bestScore) {
        best = candidate;
        bestScore = score;
      }
    }

    result = best;
  } else {
    const options = buildExampleOptions();
    result = window.OptimizerEngine.run(ssrPool, options);
  }

  applyEngineResult(result);
}

function clearTeams() {
  state.exampleMode = false;
  state.layout = {
    storyMain: Array(STORY_MAIN).fill(""),
    storyBack: Array(STORY_BACK).fill(""),
    platoons: Array.from({ length: PLATOON_COUNT }, () => Array(PLATOON_SIZE).fill("")),
  };
  saveLayout();
  renderAll();
}

function applyEngineResult(result) {
  if (!result || !result.story) return;

  // Apply only into unlocked slots. Locked slots keep what user has.
  const main = Array.isArray(result.story.main) ? result.story.main.map(normId) : [];
  const back = Array.isArray(result.story.back) ? result.story.back.map(normId) : [];

  for (let i=0;i<STORY_MAIN;i++) {
    if (!state.locks.storyMain[i]) state.layout.storyMain[i] = main[i] || "";
  }
  for (let i=0;i<STORY_BACK;i++) {
    if (!state.locks.storyBack[i]) state.layout.storyBack[i] = back[i] || "";
  }

  if (Array.isArray(result.platoons)) {
    for (let p=0;p<PLATOON_COUNT;p++) {
      const row = (result.platoons[p]?.units || []).map(normId);
      for (let i=0;i<PLATOON_SIZE;i++) {
        if (!state.locks.platoons[p][i]) state.layout.platoons[p][i] = row[i] || "";
      }
    }
  }

  saveLayout();
  renderAll();
}

function buildEngineOptions() {
  const teamType = (el("teamTypeSelect")?.value || getTeamTypePref());
  const preset   = (el("presetSelect")?.value || getPresetPref());

  setTeamTypePref(teamType);
  setPresetPref(preset);

  const options = {};
  options.doctrineOverrides = {};

  if (teamType === "mono") options.doctrineOverrides.monoVsRainbow = { selectionMode: "force_mono" };
  else if (teamType === "rainbow") options.doctrineOverrides.monoVsRainbow = { selectionMode: "force_rainbow" };
  else options.doctrineOverrides.monoVsRainbow = { selectionMode: "auto" };

  options.presetTag = (preset === "auto") ? "" : preset;
  options.presetMode = (preset === "auto") ? "auto" : "hard";

  const primaryArchetype = (el("primaryArchetypeSelect")?.value || getPrimaryArchetypePref() || "");
  const secondaryArchetype = (el("secondaryArchetypeSelect")?.value || getSecondaryArchetypePref() || "");
  options.archetypes = [primaryArchetype, secondaryArchetype].filter((v, i, arr) => v && arr.indexOf(v) === i);

  // Pass current layout + locks so engine can treat locked units as forced picks.
  options.currentLayout = structuredCloneSafe(state.layout);
  options.slotLocks = structuredCloneSafe(state.locks);

  return options;
}

function runEngine() {
  // normal optimizer = owned-only
  state.exampleMode = false;
  const owned = state.ownedUnits || [];
  if (!owned.length || !window.OptimizerEngine || typeof window.OptimizerEngine.run !== "function") return;
  const options = buildEngineOptions();
  const result = window.OptimizerEngine.run(owned, options);
  applyEngineResult(result);
}

function structuredCloneSafe(obj) {
  try { return structuredClone(obj); } catch { return JSON.parse(JSON.stringify(obj || {})); }
}

function installModeButtons() {
  const storyBtn = el("modeStory");
  const platoonsBtn = el("modePlatoons");
  if (!storyBtn || !platoonsBtn) return;

  storyBtn.addEventListener("click", () => {
    state.mode = "story";
    storyBtn.classList.add("active");
    platoonsBtn.classList.remove("active");
    renderAll();
  });

  platoonsBtn.addEventListener("click", () => {
    state.mode = "platoons";
    platoonsBtn.classList.add("active");
    storyBtn.classList.remove("active");
    renderAll();
  });
}

function lockFilledStorySlots() {
  for (let i=0;i<STORY_MAIN;i++) state.locks.storyMain[i] = !!state.layout.storyMain[i];
  for (let i=0;i<STORY_BACK;i++) state.locks.storyBack[i] = !!state.layout.storyBack[i];
  saveLocks();
  renderAll();
}

function lockFilledPlatoons() {
  for (let p=0;p<PLATOON_COUNT;p++) {
    for (let i=0;i<PLATOON_SIZE;i++) {
      state.locks.platoons[p][i] = !!state.layout.platoons[p][i];
    }
  }
  saveLocks();
  renderAll();
}

function unlockAllLocks() {
  state.locks = defaultLocks();
  saveLocks();
  renderAll();
}

// Hook entrypoint
window.refreshOptimizerFromOwned = function refreshOptimizerFromOwned() {
  state.exampleMode = false;
  state.ownedIds = getOwnedIds();
  state.ownedUnits = state.all.filter(u => state.ownedIds.has(normId(u.id)));
  window.__optimizerOwnedUnits = state.ownedUnits;
  renderAll();
};

window.runOptimizer = function runOptimizer() {
  runEngine();
};

async function init() {
  initSharedOptimizerFiltersUI();

  state.all = await loadCharacters();
  state.layout = loadLayout();
  state.locks = loadLocks();

  state.ownedIds = getOwnedIds();
  state.ownedUnits = state.all.filter(u => state.ownedIds.has(normId(u.id)));
  window.__optimizerOwnedUnits = state.ownedUnits;

  el("buildBest")?.addEventListener("click", runEngine);
  el("buildExample")?.addEventListener("click", buildExampleTeam);
  el("clearTeams")?.addEventListener("click", clearTeams);

  el("lockFilledStory")?.addEventListener("click", lockFilledStorySlots);
  el("lockFilledPlatoons")?.addEventListener("click", lockFilledPlatoons);
  el("unlockAllLocks")?.addEventListener("click", unlockAllLocks);

  installModeButtons();
  renderAll();
}

document.addEventListener("DOMContentLoaded", () => {
  init().catch(err => {
    console.error(err);
    const owned = el("ownedCount");
    if (owned) owned.textContent = `Error: ${String(err.message || err)}`;
  });
});